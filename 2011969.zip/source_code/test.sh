#!/bin/bash

gcc mem.c main.c -lpthread -o mem
./mem

